<?php
/**
 * Magestore
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Magestore.com license that is
 * available through the world-wide-web at this URL:
 * http://www.magestore.com/license-agreement.html
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Magestore
 * @package     Magestore_Affiliateplus
 * @module     Affiliateplus
 * @author      Magestore Developer
 *
 * @copyright   Copyright (c) 2016 Magestore (http://www.magestore.com/)
 * @license     http://www.magestore.com/license-agreement.html
 *
 */

class Magestore_Affiliateplus_Helper_Payment extends Mage_Core_Helper_Abstract
{
	const XML_PAYMENT_METHODS = 'affiliateplus_payment';
	
	/**
	 * Magestore_Affiliateplus_Helper_Payment::getPaymentMethod()
	 * 
	 * @param mixed $paymentMethodCode
	 * @param int $storeId
	 * @return Magestore_Affiliateplus_Model_Payment_Abstract
	 */
	public function getPaymentMethod($paymentMethodCode, $storeId = null){
		$modelPath = Mage::getStoreConfig(self::XML_PAYMENT_METHODS.'/'.$paymentMethodCode.'/model',$storeId);
		if (!$modelPath) throw new Mage_Core_Exception($this->__('Cannot find any payment method to configure'));
		
		$paymentMethod = Mage::getModel($modelPath);
		if (!($paymentMethod instanceof Magestore_Affiliateplus_Model_Payment_Abstract))
			throw new Mage_Core_Exception($this->__('The required payment model is an abstract of class %s!','Magestore_Affiliateplus_Model_Payment_Abstract'));
		
		if ($storeId)
			$paymentMethod->setStoreId($storeId);
		return $paymentMethod;
    }
    
    /**
     * get All available payment method code
     *
     * @param int $storeId
     * @return array
     */
    public function getAvailablePaymentCode($storeId = null){
    	$allPaymentConfig = Mage::getStoreConfig(self::XML_PAYMENT_METHODS,$storeId);
    	$paymentCode = array();
    	foreach ($allPaymentConfig as $code => $config)
    		if (isset($config['active']) && $config['active'])
    			$paymentCode[] = $code;
    	
    	return $paymentCode;
    }
    
    /**
     * get all available payment method
     *
     * @param int $storeId
     * @return array
     */
    public function getAvailablePayment($storeId = null){
    	$paymentCodes = $this->getAvailablePaymentCode($storeId);
    	$payments = array();
    	foreach ($paymentCodes as $paymentCode)
			try {
				$payments[$paymentCode] = $this->getPaymentMethod($paymentCode,$storeId);
			} catch (Exception $e){
				
			}
    	return $payments;
    }

    /**
     * get all payment method as an options array
     * @param null $id
     * @return array
     */
    public function getPaymentOption($id = null) {
        $allPaymentConfig = Mage::getStoreConfig(self::XML_PAYMENT_METHODS);
        $payments = array();
        foreach ($allPaymentConfig as $code => $config)
//            Changed By Adam to solve the problem 02/05/2015: Tao withdrawal cho Paypal sau day disable phuong thuc Paypal di thi khi vao view withdrawal se nhin thay phuong thuc khac chu ko phai la paypal nua
//          if (isset($config['active']) && $config['active'])
            if (!$id) {
                if (isset($config['active']) && $config['active'])
                    $payments[] = array(
                        'value' => $code,
                        'label' => $config['label'],
                    );
            }else {
                if (isset($config['active']))
                    $payments[] = array(
                        'value' => $code,
                        'label' => $config['label'],
                    );
            }
        return $payments;
    }

    /**
     * @return array
     */
    public function getAllPaymentOptionArray() {
        $allPaymentConfig = Mage::getStoreConfig(self::XML_PAYMENT_METHODS);
    	$payments = array();
        foreach ($allPaymentConfig as $code => $config) {
            if (isset($config['model'])) {
                $payments[$code] = $config['label'];
            }
        }
        return $payments;
    }
    
    /*add by blanka*/
    /**
     * @param $field
     * @param $files
     */
    public function uploadVerifyImage($field, $files){
        if(isset($files[$field]['name']) && $files[$field]['name'] != '') {
            try {
                $uploader = new Varien_File_Uploader($field);
                $uploader->setAllowedExtensions(array('jpg','jpeg','gif','png'));
                $uploader->setAllowRenameFiles(true);
                $uploader->setFilesDispersion(false);

                $path = Mage::getBaseDir('media') . DS . 'affiliateplus' . DS . 'payment' . DS;
                $file = $uploader->save($path, $files[$field]['name'] );
                return $file['file'];
            } catch (Exception $e) {

            }
        }
        return;
    }
    
    /*end*/

    /**
     * @param $code
     * @return bool
     */
    public function isRequireAuthentication($code){
        $store = Mage::app()->getStore()->getId();
        $config = Mage::getStoreConfig('affiliateplus_payment/'.$code.'/require_authentication',$store);
        if($config) return true;
        return false;
    }
}