<?php
/**
 * Magestore
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Magestore.com license that is
 * available through the world-wide-web at this URL:
 * http://www.magestore.com/license-agreement.html
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Magestore
 * @package     Magestore_Affiliateplus
 * @module     Affiliateplus
 * @author      Magestore Developer
 *
 * @copyright   Copyright (c) 2016 Magestore (http://www.magestore.com/)
 * @license     http://www.magestore.com/license-agreement.html
 *
 */

class Magestore_Affiliateplus_CheckoutController extends Mage_Core_Controller_Front_Action
{
    /**
     * @return mixed
     */
    public function creditPostAction()
    {
        // Changed By Adam 28/07/2014
        if(!Mage::helper('affiliateplus')->isAffiliateModuleEnabled()) return $this->_redirectUrl(Mage::getBaseUrl());
        
        if ($this->getRequest()->isPost()) {
            $session = Mage::getSingleton('checkout/session');
            if ($this->getRequest()->getPost('affiliateplus_credit')) {
                $session->setUseAffiliateCredit(true);
                $session->setAffiliateCredit(floatval($this->getRequest()->getPost('credit_amount')));
            } else {
                $session->setUseAffiliateCredit(false);
            }
            $session->addSuccess($this->__('Your affiliate store credit has been applied successfully'));
        }
        $this->_redirect('checkout/cart');
    }
    
    /**
     * get Account helper
     *
     * @return Magestore_Affiliateplus_Helper_Account
     */
    protected function _getAccountHelper() {
        return Mage::helper('affiliateplus/account');
    }
    
    public function changeUseCreditAction()
    {
        // Changed By Adam 28/07/2014
        if(!Mage::helper('affiliateplus')->isAffiliateModuleEnabled()) return $this->_redirectUrl(Mage::getBaseUrl());
        
        if ($this->_getAccountHelper()->disableStoreCredit()) {
            return ;
        }
        $session = Mage::getSingleton('checkout/session');
        $session->setUseAffiliateCredit($this->getRequest()->getParam('affiliatepluscredit'));
        if ($session->getAffiliateCredit() < 0.0001) {
            $session->setAffiliateCredit(10000000000);
        }
        $result = array();
        $updatepayment = ($session->getQuote()->getGrandTotal() < 0.001);
        $session->getQuote()->collectTotals()->save();
        if ($updatepayment xor ($session->getQuote()->getGrandTotal() < 0.001)) {
            $result['updatepayment'] = 1;
        } else {
            $result['html']	= $this->getLayout()->createBlock('affiliateplus/credit_form')->toHtml();
        }
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($result));
    }
    
    public function changeCreditAction()
    {
        // Changed By Adam 28/07/2014
        if(!Mage::helper('affiliateplus')->isAffiliateModuleEnabled()) return $this->_redirectUrl(Mage::getBaseUrl());
        
        if ($this->_getAccountHelper()->disableStoreCredit()) {
            return ;
        }
        $session = Mage::getSingleton('checkout/session');
        $amount = floatval($this->getRequest()->getParam('affiliatepluscredit'));
        if ($amount < 0) $amount = 0;
        $session->setAffiliateCredit($amount);
        $result = array();
        $updatepayment = ($session->getQuote()->getGrandTotal() < 0.001);
        $session->getQuote()->collectTotals()->save();
        if ($updatepayment xor ($session->getQuote()->getGrandTotal() < 0.001)) {
            $result['updatepayment'] = 1;
        } else {
            $result['html']	= $this->getLayout()->createBlock('affiliateplus/credit_form')->toHtml();
        }
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($result));
    }
}
