<?php
/**
 * Magestore
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Magestore.com license that is
 * available through the world-wide-web at this URL:
 * http://www.magestore.com/license-agreement.html
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Magestore
 * @package     Magestore_Affiliateplus
 * @module     Affiliateplus
 * @author      Magestore Developer
 *
 * @copyright   Copyright (c) 2016 Magestore (http://www.magestore.com/)
 * @license     http://www.magestore.com/license-agreement.html
 *
 */

class Magestore_Affiliatepluspayment_Adminhtml_PaymentController extends Mage_Core_Controller_Front_Action {

    /**
     * get Account helper
     *
     * @return Magestore_Affiliateplus_Helper_Account
     */
    protected function _getAccountHelper() {
        return Mage::helper('affiliateplus/account');
    }

    /**
     * get Core Session
     *
     * @return Mage_Core_Model_Session
     */
    protected function _getCoreSession() {
        return Mage::getSingleton('core/session');
    }

    /**
     * get Affiliate Payment Helper
     *
     * @return Magestore_Affiliateplus_Helper_Payment
     */
    protected function _getPaymentHelper() {
        return Mage::helper('affiliateplus/payment');
    }

    /**
     * getConfigHelper
     *
     * @return Magestore_Affiliateplus_Helper_Config
     */
    protected function _getConfigHelper() {
        return Mage::helper('affiliateplus/config');
    }

    /**
     * @return mixed
     */
    public function getStoreId() {
        $store = $this->getRequest()->getParam('store');
        return Mage::app()->getStore($store)->getId();
    }

    public function verifyMoneybookerAction() {
        $storeId = $this->getStoreId();
        $request = $this->getRequest();
        $default = $request->getParam('default');
        if ($default)
            $email = Mage::getStoreConfig('moneybookers/settings/moneybookers_email', $storeId);
        else
            $email = $request->getParam('email');
        $password = $request->getParam('password');
        $subject = $request->getParam('subject');
        $subject = $subject ? $subject : 'Affiliateplus';
        $note = $request->getParam('note');
        $note = $note ? $note : 'Affiliateplus';
        $link = 'https://www.moneybookers.com/app/pay.pl?action=prepare&email=' . $email . '&password=' . md5($password) . '&amount=1&currency=USD&bnf_email=' . $email . '&subject=' . $subject . '&note=' . $note;
        $data = Mage::helper('affiliatepluspayment/moneybooker')->readXml($link);
        $xml = simplexml_load_string($data);
        $body = '';
        if ($xml && $xml->error)
            if ($xml->error->error_msg)
                $body = (string) $xml->error->error_msg;
        if ($xml && $xml->sid)
            $body = (string) $xml->sid;
        $errors = Mage::helper('affiliatepluspayment/moneybooker')->getErrorMessages();
        if (array_key_exists($body, $errors)) {
            $body = $errors[$body];
        } elseif ($body) {
            $body = 1;
        } else {
            $body = Mage::helper('affiliatepluspayment/moneybooker')->__('Can not connect to Moneybooker server at this time');
        }
        $this->getResponse()->setBody($body);
    }

    /**
     * Check for is allowed
     *
     * @return boolean
     */
    protected function _isAllowed() {
        return Mage::getSingleton('admin/session')->isAllowed('affiliateplus/payment');
    }

}
