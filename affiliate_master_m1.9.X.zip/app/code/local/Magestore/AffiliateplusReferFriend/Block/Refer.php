<?php

/**
 * Magestore
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Magestore.com license that is
 * available through the world-wide-web at this URL:
 * http://www.magestore.com/license-agreement.html
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Magestore
 * @package     Magestore_Affiliateplus
 * @module     Affiliateplus
 * @author      Magestore Developer
 *
 * @copyright   Copyright (c) 2016 Magestore (http://www.magestore.com/)
 * @license     http://www.magestore.com/license-agreement.html
 *
 */
class Magestore_AffiliateplusReferFriend_Block_Refer extends Mage_Core_Block_Template
{
    /**
     * get Helper
     *
     * @return Magestore_Affiliateplus_Helper_Config
     */
    public function _getHelper()
    {
        return Mage::helper('affiliateplus/config');
    }

    /**
     * @return mixed
     */
    public function getReferDescription()
    {
        return $this->_getHelper()->getReferConfig('refer_description');
    }

    /**
     * @return mixed
     */
    public function getSharingDescription()
    {
        return $this->_getHelper()->getReferConfig('sharing_description');
    }

    /** Personal URL */
    public function getPersonalUrl()
    {
        if (!$this->hasData('personal_url')) {
            if ($personalPath = $this->getPersonalPath())
                $this->setData('personal_url', $this->getUrl(null, array(
                    '_direct' => $personalPath,
                    '_store_to_url' => (Mage::app()->getDefaultStoreView() && Mage::app()->getStore()->getId() != Mage::app()->getDefaultStoreView()->getId()),
                )));
            else
                $this->setData('personal_url', Mage::helper('affiliateplus/url')->addAccToUrl($this->getBaseUrl()));
        }
        return $this->getData('personal_url');
    }

    /**
     * @return mixed
     */
    public function getPrefixUrl()
    {
        $prefixurl = str_replace(" ", "", $this->getBaseUrl() . $this->_getHelper()->getReferConfig('url_prefix'));
        return $prefixurl;
    }

    /**
     * @return mixed
     */
    public function getSuffixUrl()
    {
        return $this->getUrl(null, array('_store_to_url' => (Mage::app()->getDefaultStoreView() && Mage::app()->getStore()->getId() != Mage::app()->getDefaultStoreView()->getId())));
    }

    /**
     * @return mixed
     */
    public function getCustomUrl()
    {
        if (!$this->hasData('custom_url')) {
            $this->setData('custom_url', Mage::getSingleton('core/session')->getAffilateCustomUrl());
            Mage::getSingleton('core/session')->setAffilateCustomUrl(null);
        }
        return $this->getData('custom_url');
    }

    /** Email */
    public function getAccount()
    {
        return Mage::getSingleton('affiliateplus/session')->getAccount();
    }

    /**
     * @return mixed
     */
    public function getAccountEmail()
    {
        return $this->getAccount()->getEmail();
    }

    /**
     * @return mixed
     */
    public function getDefaultEmailSubject()
    {
        return $this->_getHelper()->getReferConfig('email_subject');
    }

    /**
     * @return mixed
     */
    public function getDefaultEmailContent()
    {
        $content = $this->_getHelper()->getReferConfig('email_content');
        if ($this->getPersonalPath()) {
            $personalUrl = $this->getPersonalUrl();
        } else {
            $personalUrl = Mage::helper('affiliateplus/url')->addAccToUrl(
                $this->getUrl(null, array('_query' => array('src' => 'email')))
            );
        }
        return str_replace(
            array(
                '{{store_name}}',
                '{{personal_url}}',
                '{{account_name}}'
            ), array(
            Mage::app()->getStore()->getFrontendName(),
            $personalUrl,
            $this->getAccount()->getName()
        ), $content
        );
    }

    /**
     * @return mixed
     */
    public function getEmailFormData()
    {
        if (!$this->hasData('email_form_data')) {
            $data = Mage::getSingleton('core/session')->getEmailFormData();
            Mage::getSingleton('core/session')->setEmailFormData(null);
            $dataObj = new Varien_Object($data);
            $this->setData('email_form_data', $dataObj);
        }
        return $this->getData('email_form_data');
    }

    /**
     * @return mixed
     */
    public function getJsonEmail()
    {
        $result = array(
//            'yahoo' => $this->getUrl('*/*/yahoo'),
//            'gmail' => $this->getUrl('*/*/gmail'),
//            'hotmail'	=> $this->getUrl('*/*/hotmail'),
            'yahoo' => "http://mail.yahoo.com",
            'gmail' => "http://gmail.com",
            'hotmail' => "http://hotmail.com",
        );
        return Zend_Json::encode($result);
    }

    /**
     * @return mixed
     */
    public function getDefaultSharingContent()
    {
        $content = $this->_getHelper()->getReferConfig('sharing_message');
        return str_replace(
            array(
                '{{store_name}}',
                '{{personal_url}}'
            ), array(
            Mage::app()->getStore()->getFrontendName(),
            $this->getPersonalUrl()
        ), $content
        );
    }

    /**
     * @return mixed
     */
    public function getDefaultTwitterContent()
    {
        $content = $this->_getHelper()->getReferConfig('twitter_message');
        return str_replace(
            array(
                '{{store_name}}',
                '{{personal_url}}'
            ), array(
            Mage::app()->getStore()->getFrontendName(),
            $this->getPersonalUrl()
        ), $content
        );
    }

    /** Facebook */
    public function getFbLoginUrl()
    {
        return $this->getUrl('*/*/facebook', array('auth' => 1));
        try {
            if (!class_exists('Facebook'))
                require_once(Mage::getBaseDir('lib') . DS . 'Facebookv3' . DS . 'facebook.php');
            $facebook = new Facebook(array(
                'appId' => $this->_getHelper()->getReferConfig('fbapp_id'),
                'secret' => $this->_getHelper()->getReferConfig('fbapp_secret'),
                'cookie' => true
            ));
            $loginUrl = $facebook->getLoginUrl(array(
                'display' => 'popup',
                'redirect_uri' => $this->getUrl('*/*/facebook', array('auth' => 1)),
                'scope' => 'publish_stream,email',
            ));
            return $loginUrl;
        } catch (Exception $e) {

        }
    }

    /**
     * @return string
     */
    public function getActiveTab()
    {
        if ($tab = $this->getRequest()->getParam('tab')) {
            if (in_array($tab, array('email', 'facebook', 'twitter', 'google'))) {
                return "affiliate-opc-$tab-content";
            }
        }
        return '';
    }

    /**
     * @param $_tab
     * @return bool
     */
    public function isActiveTab($_tab)
    {
        if ($tab = $this->getRequest()->getParam('tab')) {
            return ($tab == $_tab);
        }
        return false;
    }

    /**
     * get Traffic source statistic
     *
     * @return array
     */
    public function getTrafficSources()
    {
        $accountId = $this->getAccount()->getId();
        $referers = Mage::getResourceModel('affiliateplus/action_collection')->addFieldToFilter('account_id', $accountId);
        $referers->getSelect()
            ->columns(array('total_clicks' => 'SUM(totals)'))
            ->group(array('referer', 'landing_page', 'store_id'));
        $trafficSources = array('facebook' => 0, 'twitter' => 0, 'google' => 0, 'email' => 0);
        foreach ($referers as $refer) {
            $referer = $refer->getData('referer');
            // Changed By Adam: 20/10/2014: Warning: strpos(): Empty needle  in C:\xampp\htdocs\project\magento1.5.0.1\app\code\local\Magestore\AffiliateplusReferFriend\Block\Refer.php on line 188
            if ($this->getPersonalPath() && ($refer && $refer->getData('landing_page')) === false || strpos($this->getPersonalPath(), trim($refer->getData('landing_page'), '/')) === false)
                continue;
            if (strpos($referer, 'facebook.com') !== false) {
                $trafficSources['facebook'] += $refer->getData('total_clicks');
            } elseif (strpos($referer, 'plus.url.google.com') !== false) {
                $trafficSources['google'] += $refer->getData('total_clicks');
            } elseif (strpos($referer, 't.co') !== false || strpos($referer, 'twitter.com') !== false) {
                $trafficSources['twitter'] += $refer->getData('total_clicks');
            } elseif ($this->getPersonalPath()) {
                $trafficSources['email'] += $refer->getData('total_clicks');
            } elseif (strpos($referer, 'mail') !== false) {
                $trafficSources['email'] += $refer->getData('total_clicks');
            }
        }
        return $trafficSources;
    }

    /**
     * @return mixed
     */
    public function getPersonalPath()
    {
        if (!$this->hasData('personal_path')) {
            $idPath = 'affiliateplus/' . Mage::app()->getStore()->getId() . '/' . $this->getAccount()->getId();
            $rewrite = Mage::getModel('core/url_rewrite')->load($idPath, 'id_path');
            if ($rewrite->getId())
                $this->setData('personal_path', $rewrite->getRequestPath());
            else
                $this->setData('personal_path', false);
        }
        return $this->getData('personal_path');
    }
}
