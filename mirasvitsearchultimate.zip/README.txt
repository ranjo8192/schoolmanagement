Carefully follow the manual for installation, configuration, upgrading and removing the extension from your store https://mirasvit.com/doc/ssu/2.3.4/

You have a free support period till Sep 24, 2017. If you need a help, please, contact our support team https://mirasvit.com/support/.
