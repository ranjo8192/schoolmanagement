<?php
class Mirasvit_SearchIndex_Helper_Code extends Mirasvit_MstCore_Helper_Code
{
    protected $k = "EPUYK17M63";
    protected $s = "SSU";
    protected $l = "30299";
    protected $v = "2.3.3.1";
    protected $b = "1379";
    protected $d = "medsengage.com";
}
