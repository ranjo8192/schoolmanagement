<?php
class Ranjeet_Cartupdate_Model_Observer 
{
	public function cartProductAddAfter(Varien_Event_Observer $observer) {
			
		Mage::log('text here', null, 'test.log', true);
			//die;
		  
        $item = $observer->getQuoteItem();
        // Check if Product have parent item.
        $item = ( $item->getParentItem() ? $item->getParentItem() : $item );
       
        // Load the custom price
        $price = 1234; //Here, set the Custom Price for Item
        // Set the custom price
        $item->setCustomPrice($price); // This set the Custom Price in Quote of cart
        $item->setOriginalCustomPrice($price);
        // Enable super mode on the product.
        $item->getProduct()->setIsSuperMode(true);  

        }
       
	

     
    }
?>
