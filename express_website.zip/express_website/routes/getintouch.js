var express = require('express');
var router = express.Router();
var nodemailer = require('nodemailer');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('getintouch', { title: 'Get In Touch' });
});

router.post('/send', function(req, res, next){
	var transporter = nodemailer.createTransport({
		service: 'Gmail',
		auth: {
			user: 'kushwaha.ranjeet8192@gmail.com',
			pass: 'er.ranjee8@#45100'
		}
	});

	var mainOptions = {
		form: 'Ranjeet Singh <tech@offshorecheapmeds.com>',
		to: 'kushwaha.ranjeet8192@gmail.com',
		subject: 'Get in touch contact form express website',
		text: 'You have new submission with the following details..Name:' +req.body.name+ 'email: ' +req.body.email+ 'Mobile:' +req.body.mobile+ 'Subject' +req.body.subject+ 'Message' +req.body.message ,
		html: '<p>You git a new submission with the following details..</p><ul><li>Name:' +req.body.name+ '</li><li>Email: ' +req.body.email+ '</li><li>Moblie: ' +req.body.mobile+ '</li><li>Subject: ' +req.body.subject+ '</li><li> Message: ' +req.body.message+ '</li></ul>'
	};

	transporter.sendMail(mainOptions, function(err, info){
		if(err){
			console.log(err);
			res.redirect('/');
		} else {
			console.log('Message Sent: ' +info.response);
			res.redirect('/');
		}
	});
});

module.exports = router;
