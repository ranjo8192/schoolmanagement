<?php
class Tvbocm_RefillOrderForm_Block_RefillOrderForm extends Mage_Core_Block_Template
{
	public function _prepareLayout(){
	    
		return parent::_prepareLayout();
		
	}
}
?>